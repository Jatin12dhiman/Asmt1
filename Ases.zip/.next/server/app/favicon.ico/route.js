var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/7684b_next_9243b1ba._.js")
R.c("server/chunks/[root-of-the-server]__c80f00c8._.js")
R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/favicon--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
