__turbopack_load_page_chunks__("/_app", [
  "static/chunks/7684b_next_dist_compiled_next-devtools_index_bd11238e.js",
  "static/chunks/7684b_next_dist_compiled_ecbeb8ae._.js",
  "static/chunks/7684b_next_dist_shared_lib_21030705._.js",
  "static/chunks/7684b_next_dist_client_b1df54ef._.js",
  "static/chunks/7684b_next_dist_46775249._.js",
  "static/chunks/7684b_next_app_f1252cb6.js",
  "static/chunks/[next]_entry_page-loader_ts_72492fc1._.js",
  "static/chunks/7684b_react-dom_cb8ca1db._.js",
  "static/chunks/7684b_96a8eb64._.js",
  "static/chunks/[root-of-the-server]__26245388._.js",
  "static/chunks/OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__app_2da965e7._.js",
  "static/chunks/turbopack-OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__app_198b51a2._.js"
])
