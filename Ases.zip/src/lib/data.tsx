export const clientData = [
    { name: "Lucident", slug: "lucident", icon: "/icons/lucident.svg" },
    { name: "Morance", slug: "morance", icon: "/icons/morance.svg" },
    { name: "invarion", slug: "invarion", icon: "/icons/invarion.svg" },
    { name: "MARCO PIERRE", slug: "marco-pierre", icon: "/icons/marco-pierre.svg" },
    { name: "CodeWays", slug: "codeways", icon: "/icons/codeways.svg" },
    { name: "Innovate", slug: "innovate", icon: "/icons/innovate.svg" },
    { name: "TechNova", slug: "technova", icon: "/icons/technova.svg" },
    { name: "Artifact", slug: "artifact", icon: "/icons/artifact.svg" },
  ];