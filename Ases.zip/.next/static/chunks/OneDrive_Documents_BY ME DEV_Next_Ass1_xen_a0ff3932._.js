(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_32cf580a._.js",
  "static/chunks/7684b_next_dist_compiled_react-dom_312afa7f._.js",
  "static/chunks/7684b_next_dist_compiled_next-devtools_index_f8e6f2ad.js",
  "static/chunks/7684b_next_dist_compiled_307f41b3._.js",
  "static/chunks/7684b_next_dist_client_69987dbd._.js",
  "static/chunks/7684b_next_dist_20b00ea8._.js",
  "static/chunks/7684b_@swc_helpers_cjs_3d9f49c8._.js"
],
    source: "entry"
});
