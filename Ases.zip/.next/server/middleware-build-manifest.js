globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/7684b_next_dist_compiled_next-devtools_index_bd11238e.js",
      "static/chunks/7684b_next_dist_compiled_ecbeb8ae._.js",
      "static/chunks/7684b_next_dist_shared_lib_21030705._.js",
      "static/chunks/7684b_next_dist_client_b1df54ef._.js",
      "static/chunks/7684b_next_dist_46775249._.js",
      "static/chunks/7684b_next_app_f1252cb6.js",
      "static/chunks/[next]_entry_page-loader_ts_72492fc1._.js",
      "static/chunks/7684b_react-dom_cb8ca1db._.js",
      "static/chunks/7684b_96a8eb64._.js",
      "static/chunks/[root-of-the-server]__26245388._.js",
      "static/chunks/OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__app_2da965e7._.js",
      "static/chunks/turbopack-OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__app_198b51a2._.js"
    ],
    "/_error": [
      "static/chunks/7684b_next_dist_compiled_next-devtools_index_bd11238e.js",
      "static/chunks/7684b_next_dist_compiled_ecbeb8ae._.js",
      "static/chunks/7684b_next_dist_shared_lib_871420ee._.js",
      "static/chunks/7684b_next_dist_client_b1df54ef._.js",
      "static/chunks/7684b_next_dist_512fe459._.js",
      "static/chunks/7684b_next_error_a6b675cb.js",
      "static/chunks/[next]_entry_page-loader_ts_a9cb15f7._.js",
      "static/chunks/7684b_react-dom_cb8ca1db._.js",
      "static/chunks/7684b_96a8eb64._.js",
      "static/chunks/[root-of-the-server]__8e9b33bf._.js",
      "static/chunks/OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__error_2da965e7._.js",
      "static/chunks/turbopack-OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__error_6159efb8._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/7684b_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_32cf580a._.js",
    "static/chunks/7684b_next_dist_compiled_react-dom_312afa7f._.js",
    "static/chunks/7684b_next_dist_compiled_next-devtools_index_f8e6f2ad.js",
    "static/chunks/7684b_next_dist_compiled_307f41b3._.js",
    "static/chunks/7684b_next_dist_client_69987dbd._.js",
    "static/chunks/7684b_next_dist_20b00ea8._.js",
    "static/chunks/7684b_@swc_helpers_cjs_3d9f49c8._.js",
    "static/chunks/OneDrive_Documents_BY ME DEV_Next_Ass1_xen_a0ff3932._.js",
    "static/chunks/turbopack-OneDrive_Documents_BY ME DEV_Next_Ass1_xen_04ff82ad._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];