(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/OneDrive_Documents_BY ME DEV_Next_Ass1_xen_src_app_components_764b88e3._.js",
  "static/chunks/7684b_8095d79a._.js"
],
    source: "dynamic"
});
