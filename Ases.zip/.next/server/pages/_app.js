var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__6abfd7e5._.js")
R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/app.js [ssr] (ecmascript)").exports
