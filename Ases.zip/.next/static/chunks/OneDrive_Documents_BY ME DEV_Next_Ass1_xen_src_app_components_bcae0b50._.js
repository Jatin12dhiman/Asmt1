(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const Hero = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "bg-white text-black py-20 px-2 md:px-4 lg:px-4 ",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto flex flex-col md:flex-row items-center justify-between gap-10 ",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "flex-1 max-w-2xl text-center md:text-left ",
                    initial: {
                        opacity: 0,
                        x: -50
                    },
                    whileInView: {
                        opacity: 1,
                        x: 0
                    },
                    viewport: {
                        once: true,
                        amount: 0.3
                    },
                    transition: {
                        duration: 0.8
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-600 mb-2 font-semibold",
                            children: "Welcome to Artifact"
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-4xl md:text-6xl font-semibold leading-tight mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "inline",
                                    children: " Streamline operations in "
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 21,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                "one unified platform"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 20,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text text-gray-800 mb-8 font-semibold",
                            children: "Artifact’s unified platform transforms scattered insights into optimized automation technical knowledge optional."
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 23,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "relative bg-black text-white px-6 py-3 rounded-full text-sm font-medium overflow-hidden group transition-all duration-300 focus:outline-none focus:ring-0 active:outline-none",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "block transition-all duration-500 group-hover:-translate-y-full group-hover:opacity-0",
                                    children: "Get Started"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-0 flex items-center justify-center translate-y-full opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100",
                                    children: "Get Started"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 33,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-center md:justify-start mt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mr-2 text-gray-500",
                                    children: "G2"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex text-gray-500 mr-2",
                                    children: [
                                        ...Array(5)
                                    ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                                            className: "w-5 h-5 fill-current"
                                        }, i, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                            lineNumber: 42,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)))
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 40,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm text-gray-500",
                                    children: "620+ Reviews"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 45,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "flex-1 grid gap-2 w-full max-w-xl",
                    initial: {
                        opacity: 0,
                        x: 50
                    },
                    whileInView: {
                        opacity: 1,
                        x: 0
                    },
                    viewport: {
                        once: true,
                        amount: 0.3
                    },
                    transition: {
                        duration: 0.8
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-full",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    className: "relative w-full pb-[100%] rounded-lg overflow-hidden",
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    viewport: {
                                        once: true,
                                        amount: 0.3
                                    },
                                    transition: {
                                        duration: 0.6,
                                        delay: 0.2
                                    },
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/Images/ass1.webp",
                                        alt: "Man looking forward",
                                        fill: true,
                                        sizes: "(max-width: 640px) 100vw, 50vw",
                                        className: "object-cover object-center",
                                        priority: true
                                    }, void 0, false, {
                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                        lineNumber: 67,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 60,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    className: "relative rounded-lg bg-black text-white p-4 sm:p-6 md:p-8 flex flex-col justify-between h-auto sm:h-72 md:h-96",
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    viewport: {
                                        once: true,
                                        amount: 0.3
                                    },
                                    transition: {
                                        duration: 0.6,
                                        delay: 0.4
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            className: "text-2xl sm:text-3xl md:text-4xl font-semibold leading-snug antialiased",
                                            children: [
                                                "65% Increase",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block text-gray-400 text-sm sm:text-base md:text-lg",
                                                    children: "in operational efficiency"
                                                }, void 0, false, {
                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                                    lineNumber: 87,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                            lineNumber: 85,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs sm:text-sm md:text-base text-gray-400 mt-2 sm:mt-4 font-semibold",
                                            children: "From customers who used Artifact for at least 12 months."
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                            lineNumber: 91,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 78,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            className: "relative rounded-lg h-36 w-full overflow-hidden",
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            viewport: {
                                once: true,
                                amount: 0.3
                            },
                            transition: {
                                duration: 0.6,
                                delay: 0.6
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: "/Images/Bg.jpg",
                                    alt: "Sales trends background",
                                    fill: true,
                                    sizes: "(max-width: 768px) 100vw, 50vw",
                                    className: "object-cover cursor-pointer",
                                    priority: false
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 105,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-0 flex items-center justify-center p-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 bg-[#2b2524]/90 text-white px-4 sm:px-5 py-2 sm:py-2.5 rounded-xl shadow-lg backdrop-blur-sm border border-white/10",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                viewBox: "0 0 24 24",
                                                className: "h-5 w-5 opacity-90",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    d: "M3 3h2v18H3zM7 7h2v14H7zM11 11h2v10h-2zM15 5h2v16h-2zM19 9h2v12h-2z"
                                                }, void 0, false, {
                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                                    lineNumber: 116,
                                                    columnNumber: 19
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                                lineNumber: 115,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-sm sm:text-base font-semibold whitespace-nowrap",
                                                children: "Summarize trends from Q1 sales data"
                                            }, void 0, false, {
                                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                                lineNumber: 118,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                        lineNumber: 114,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                                    lineNumber: 113,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
                    lineNumber: 50,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Hero.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Hero;
const __TURBOPACK__default__export__ = Hero;
var _c;
__turbopack_context__.k.register(_c, "Hero");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/image.js [app-client] (ecmascript)");
'use client';
;
;
;
const Items = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-6 md:gap-10 lg:gap-16 whitespace-nowrap shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl md:text-2xl lg:text-5xl font-semibold ml-8",
                children: "Grow quicker."
            }, void 0, false, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 8,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl md:text-2xl lg:text-5xl font-semibold",
                children: "Build better."
            }, void 0, false, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 9,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative h-8 w-8 md:h-16 md:w-20 rounded-lg overflow-hidden shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: "/Images/Bg.jpg",
                        alt: "chip",
                        fill: true,
                        className: "object-cover"
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                        lineNumber: 12,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: "/Images/image 1.svg",
                        alt: "overlay",
                        fill: true,
                        sizes: "(max-width: 768px) 2rem, 5rem",
                        className: "absolute object-contain p-1"
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                        lineNumber: 13,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 11,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl md:text-2xl lg:text-5xl font-semibold",
                children: "Ideate faster."
            }, void 0, false, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 22,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl md:text-2xl lg:text-5xl font-semibold",
                children: "Work smarter."
            }, void 0, false, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 23,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative h-8 w-8 md:h-16 md:w-20 rounded-lg overflow-hidden shrink-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: "/Images/Bg.jpg",
                        alt: "chip",
                        fill: true,
                        className: "object-cover"
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                        lineNumber: 26,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: "/Images/image 1.svg",
                        alt: "overlay",
                        fill: true,
                        sizes: "(max-width: 768px) 2rem, 5rem",
                        className: "absolute object-contain "
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                        lineNumber: 27,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 25,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
        lineNumber: 7,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = Items;
function HorizontalStrip() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "bg-black text-white py-6 px-4 overflow-hidden",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-6 marquee-row cursor-pointer",
                    style: {
                        width: "fit-content"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Items, {}, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                            lineNumber: 52,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Items, {
                            "aria-hidden": "true"
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                            lineNumber: 53,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                    lineNumber: 45,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
                lineNumber: 44,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/HorizontalStrip.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_c1 = HorizontalStrip;
const __TURBOPACK__default__export__ = HorizontalStrip;
var _c, _c1;
__turbopack_context__.k.register(_c, "Items");
__turbopack_context__.k.register(_c1, "HorizontalStrip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
"use client";
;
;
;
const Features = ()=>{
    const cards = [
        {
            id: 1,
            title: "Agents for Anything",
            description: "Artifact synchronizes enterprise data across distributed sources for continuous operational intelligence.",
            frontImage: "/Images/Fe1.avif",
            backgroundImage: "/Images/Bg.jpg"
        },
        {
            id: 2,
            title: "Manage Instances",
            description: "Through intelligent protocols, Artifact delivers continuous data harmonization across ecosystems.",
            frontImage: "/Images/Fe2.avif",
            backgroundImage: "/Images/Bg.jpg"
        },
        {
            id: 3,
            title: "Seamless Integrations",
            description: "Effortlessly connect with your existing tools and workflows for maximum efficiency.",
            frontImage: "/Images/Fe3.avif",
            backgroundImage: "/Images/Bg.jpg"
        },
        {
            id: 4,
            title: "Real-time Insights",
            description: "Gain actionable intelligence instantly with Artifact’s real-time analytics and monitoring.",
            frontImage: "/Images/Fe4.avif",
            backgroundImage: "/Images/Bg.jpg"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "bg-[#f7f4f0] text-black py-20 px-4 md:px-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "text-center mb-16",
                    initial: {
                        opacity: 0,
                        y: 30
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: true
                    },
                    transition: {
                        duration: 0.6
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "mx-auto max-w-[20ch] text-4xl sm:text-5xl md:text-6xl lg:text-6xl font-semibold leading-tight tracking-tight",
                            children: "Automation that actually understands you"
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-6 md:mt-8 text-base md:text-lg text-gray-600 max-w-3xl mx-auto font-medium",
                            children: "Deploy Artifact's proven optimization protocols for sustainable growth."
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                    lineNumber: 46,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 lg:gap-6 mx-2 md:mx-16",
                    children: cards.map((card, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                            className: "group relative overflow-hidden rounded-sm ring-1 ring-black/5 flex flex-col h-auto",
                            initial: {
                                opacity: 0,
                                y: 50
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            viewport: {
                                once: true,
                                amount: 0.3
                            },
                            transition: {
                                duration: 0.6,
                                delay: index * 0.2
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative w-full bg-[#eae6e2] overflow-hidden min-h-[260px] md:min-h-[400px] pt-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "absolute inset-0 z-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500",
                                            initial: {
                                                scale: 1
                                            },
                                            whileInView: {
                                                scale: 1.05
                                            },
                                            viewport: {
                                                once: true
                                            },
                                            transition: {
                                                duration: 0.5
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: card.backgroundImage,
                                                alt: "Background effect",
                                                fill: true,
                                                className: "object-cover"
                                            }, void 0, false, {
                                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                                lineNumber: 83,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                            lineNumber: 76,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                            className: "relative z-10 transition-transform duration-500 m-6 md:m-8 group-hover:scale-108 group-hover:-translate-y-2 p-8",
                                            initial: {
                                                scale: 0.95
                                            },
                                            whileInView: {
                                                scale: 1
                                            },
                                            viewport: {
                                                once: true
                                            },
                                            transition: {
                                                duration: 0.5
                                            },
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "w-full aspect-[16/9] flex items-center justify-center",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    src: card.frontImage,
                                                    alt: card.title,
                                                    fill: true,
                                                    className: "object-contain rounded-lg \n                        ".concat(card.id === 2 ? "translate-x-[40%] scale-125" : "", " \n                        ").concat(card.id === 4 ? "translate-y-[20%] scale-133" : "")
                                                }, void 0, false, {
                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 21
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                                lineNumber: 99,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                            lineNumber: 92,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                    lineNumber: 74,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                    className: "w-full bg-white p-4 sm:p-5 md:p-6 text-left flex flex-col",
                                    initial: {
                                        opacity: 0,
                                        y: 20
                                    },
                                    whileInView: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    viewport: {
                                        once: true
                                    },
                                    transition: {
                                        duration: 0.5,
                                        delay: 0.3
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-base sm:text-base md:text-lg font-semibold mb-1 sm:mb-2",
                                            children: card.title
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                            lineNumber: 120,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-600 leading-snug text-sm sm:text-sm md:text-base font-normal",
                                            children: card.description
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                            lineNumber: 123,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                    lineNumber: 113,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, card.id, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                            lineNumber: 65,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                    lineNumber: 63,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "mt-16 bg-black text-white rounded-xl px-4 py-6 max-w-3xl mx-auto shadow-sm md:hidden",
                    initial: {
                        opacity: 0,
                        y: 50
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: true
                    },
                    transition: {
                        duration: 0.6,
                        delay: 0.2
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center text-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: "/Images/Fe5.avif",
                                alt: "Support",
                                width: 64,
                                height: 64,
                                className: "rounded-full ring-2 ring-white/10"
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                lineNumber: 140,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-base font-semibold",
                                children: [
                                    "Hello ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "align-middle",
                                        children: "👋"
                                    }, void 0, false, {
                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                        lineNumber: 141,
                                        columnNumber: 58
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    " I’m Jake from support."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                lineNumber: 141,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-300 text-sm max-w-xl",
                                children: "Let me know if you have any questions about Artifact."
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                lineNumber: 142,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "mt-3 bg-white text-black px-5 py-2 rounded-full font-medium hover:bg-gray-200 transition",
                                children: "Contact us"
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                lineNumber: 143,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                        lineNumber: 139,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                    lineNumber: 132,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    className: "mt-16 hidden md:flex items-center justify-between bg-black text-white rounded-full px-6 py-4 md:px-10 md:py-6 max-w-4xl mx-auto",
                    initial: {
                        opacity: 0,
                        y: 50
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    viewport: {
                        once: true
                    },
                    transition: {
                        duration: 0.6,
                        delay: 0.4
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: "/Images/Fe5.avif",
                                    alt: "Support",
                                    width: 50,
                                    height: 50,
                                    className: "rounded-full"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                    lineNumber: 155,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "font-semibold",
                                            children: "Hello 👋 I’m Jake from support."
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                            lineNumber: 157,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-300 text-sm md:text-base",
                                            children: "Let me know if you have any questions about Artifact."
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                            lineNumber: 158,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                    lineNumber: 156,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                            lineNumber: 154,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "relative bg-white text-black px-5 py-2 rounded-full font-medium overflow-hidden group transition-colors hover:bg-gray-200 focus:outline-none focus:ring-0 active:outline-none",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "block transition-all duration-500 group-hover:-translate-y-full group-hover:opacity-0",
                                    children: "Contact us"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                    lineNumber: 164,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-0 flex items-center justify-center translate-y-full opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100 bg-black text-white",
                                    children: "Contact us"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                                    lineNumber: 167,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                            lineNumber: 161,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
                    lineNumber: 147,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
            lineNumber: 44,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Features.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Features;
const __TURBOPACK__default__export__ = Features;
var _c;
__turbopack_context__.k.register(_c, "Features");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const CustomerTestimonials = ()=>{
    _s();
    const [currentIndex, setCurrentIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [cardsPerView, setCardsPerView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(2);
    const testimonials = [
        {
            id: 1,
            name: "José Morales",
            title: "Head of Innovation",
            quote: "We expected performance improvements, but the strategic implementation delivered unprecedented operational excellence.",
            image: "/Images/Cs1.webp"
        },
        {
            id: 2,
            name: "Andrew Ye",
            title: "Product Strategy Lead",
            quote: "Beyond the clear ROI metrics, what stood out was how the solution scaled with our strategic objectives.",
            image: "/Images/Cs2.webp"
        },
        {
            id: 3,
            name: "Sarah Chen",
            title: "Operations Director",
            quote: "The implementation exceeded our expectations and transformed our entire workflow process.",
            image: "/Images/Cs3.webp"
        },
        {
            id: 4,
            name: "Michael Torres",
            title: "Chief Technology Officer",
            quote: "Artifact's solution provided the scalability and reliability we needed for our growing business.",
            image: "/Images/Cs4.webp"
        }
    ];
    // Dynamically update cards per view on resize
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CustomerTestimonials.useEffect": ()=>{
            const updateCards = {
                "CustomerTestimonials.useEffect.updateCards": ()=>{
                    setCardsPerView(window.innerWidth < 768 ? 1 : 2);
                }
            }["CustomerTestimonials.useEffect.updateCards"];
            updateCards();
            window.addEventListener('resize', updateCards);
            return ({
                "CustomerTestimonials.useEffect": ()=>window.removeEventListener('resize', updateCards)
            })["CustomerTestimonials.useEffect"];
        }
    }["CustomerTestimonials.useEffect"], []);
    const maxIndex = testimonials.length - cardsPerView;
    const handlePrev = ()=>setCurrentIndex((prev)=>Math.max(0, prev - 1));
    const handleNext = ()=>setCurrentIndex((prev)=>Math.min(maxIndex, prev + 1));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto px-2 md:px-4 lg:px-4 py-12 bg-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-12 text-left",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-5xl font-semibold text-gray-900 mb-6",
                        children: [
                            "See why customers use Artifact ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                lineNumber: 35,
                                columnNumber: 52
                            }, ("TURBOPACK compile-time value", void 0)),
                            "to power their businesses"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 34,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "relative bg-black text-white px-6 py-3 rounded-full text-sm font-medium overflow-hidden group transition-colors hover:bg-gray-800",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "block transition-all duration-500 group-hover:-translate-y-full group-hover:opacity-0",
                                children: "Customer stories"
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                lineNumber: 40,
                                columnNumber: 21
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "absolute inset-0 flex items-center justify-center translate-y-full opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100",
                                children: "Customer stories"
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                lineNumber: 45,
                                columnNumber: 21
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 38,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                lineNumber: 33,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-4 transition-transform duration-500 ease-in-out",
                    style: {
                        transform: "translateX(-".concat(currentIndex * (cardsPerView === 1 ? 100 : 50), "%)")
                    },
                    children: testimonials.map((testimonial)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-shrink-0 w-full md:w-1/2 px-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative h-[600px] sm:h-[460px] md:h-[430px] lg:h-[440px] rounded-2xl overflow-hidden shadow-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: "/Images/Bg.jpg",
                                        alt: "background",
                                        className: "absolute inset-0 w-full h-full object-cover",
                                        style: {
                                            objectPosition: 'left bottom'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                        lineNumber: 64,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative z-10 h-full p-3 sm:p-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-full flex flex-col gap-3 md:grid md:grid-cols-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-shrink-0 h-[400px] sm:h-[350px] md:col-span-1 md:h-full rounded-xl overflow-hidden bg-white/10 backdrop-blur-[1px] md:min-h-[300px]",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: testimonial.image,
                                                        alt: testimonial.name,
                                                        className: "w-full h-full object-cover object-center"
                                                    }, void 0, false, {
                                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                        lineNumber: 76,
                                                        columnNumber: 45
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                }, void 0, false, {
                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                    lineNumber: 75,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1 flex flex-col gap-3 md:col-span-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "bg-white rounded-xl shadow border p-3 sm:p-4 md:p-5 flex-1 flex items-center md:min-h-[190px]",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
                                                                className: "text-gray-900 text-sm sm:text-[15px] md:text-base leading-relaxed font-semibold",
                                                                children: '"'.concat(testimonial.quote, '"')
                                                            }, void 0, false, {
                                                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                                lineNumber: 86,
                                                                columnNumber: 49
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        }, void 0, false, {
                                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                            lineNumber: 85,
                                                            columnNumber: 45
                                                        }, ("TURBOPACK compile-time value", void 0)),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "bg-white rounded-xl shadow border p-3 sm:p-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                    className: "font-semibold text-gray-900 text-[13px] sm:text-base",
                                                                    children: testimonial.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                                    lineNumber: 91,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0)),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-600 text-xs sm:text-sm leading-snug",
                                                                    children: testimonial.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                                    lineNumber: 92,
                                                                    columnNumber: 49
                                                                }, ("TURBOPACK compile-time value", void 0))
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                            lineNumber: 90,
                                                            columnNumber: 45
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                    lineNumber: 84,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                            lineNumber: 73,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                        lineNumber: 71,
                                        columnNumber: 33
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                lineNumber: 62,
                                columnNumber: 29
                            }, ("TURBOPACK compile-time value", void 0))
                        }, testimonial.id, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                            lineNumber: 61,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)))
                }, void 0, false, {
                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                    lineNumber: 54,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                lineNumber: 53,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-3 mt-6 justify-center md:justify-start",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handlePrev,
                        disabled: currentIndex === 0,
                        className: "w-10 h-10 rounded-full border-2 border-gray-300 bg-white flex items-center justify-center transition-all ".concat(currentIndex === 0 ? 'opacity-50 cursor-not-allowed' : 'hover:border-gray-400 hover:bg-gray-50'),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                            className: "w-5 h-5 text-gray-600"
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                            lineNumber: 110,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 104,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        disabled: currentIndex >= maxIndex,
                        onClick: handleNext,
                        className: "w-10 h-10 rounded-full border-2 border-gray-300 bg-white flex items-center justify-center transition-all ".concat(currentIndex >= maxIndex ? 'opacity-50 cursor-not-allowed' : 'hover:border-gray-400 hover:bg-gray-50'),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                            className: "w-5 h-5 text-gray-600"
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                            lineNumber: 118,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 112,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                lineNumber: 103,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-14",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-gray-800 font-medium",
                        children: "Join over 1,000 companies using Artifact to build content that fits with any brand."
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 124,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative mt-6 overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pointer-events-none absolute left-0 top-0 h-full w-24 bg-gradient-to-r from-white to-transparent z-10"
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                lineNumber: 129,
                                columnNumber: 21
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "pointer-events-none absolute right-0 top-0 h-full w-24 bg-gradient-to-l from-white to-transparent z-10"
                            }, void 0, false, {
                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                lineNumber: 130,
                                columnNumber: 21
                            }, ("TURBOPACK compile-time value", void 0)),
                            (()=>{
                                const brands = [
                                    'DUNHAM & CO.',
                                    'Gridpoint',
                                    'MORANCE',
                                    'invarion',
                                    'continuum.ai',
                                    'DURAPIPE',
                                    'Monolith',
                                    'Spectra'
                                ];
                                const Row = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-12 md:gap-20 whitespace-nowrap",
                                        children: brands.map((b, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-gray-500 text-xl md:text-2xl lg:text-3xl font-semibold tracking-wide",
                                                children: b
                                            }, i, false, {
                                                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                                lineNumber: 146,
                                                columnNumber: 37
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                        lineNumber: 144,
                                        columnNumber: 29
                                    }, ("TURBOPACK compile-time value", void 0));
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "marquee-row flex items-center gap-12 md:gap-20",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {}, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                            lineNumber: 154,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {}, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                            lineNumber: 155,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Row, {
                                            "aria-hidden": "true"
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                            lineNumber: 156,
                                            columnNumber: 33
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                    lineNumber: 153,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0));
                            })()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 127,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                lineNumber: 123,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-16 md:mt-24",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-3xl md:text-5xl font-semibold text-gray-900 text-center mb-10",
                        children: "You may be wondering..."
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 165,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    (()=>{
                        const faqs = [
                            {
                                q: 'What is Artifact?',
                                a: 'Artifact is a SaaS platform that helps businesses automate workflows, integrate tools, and scale effortlessly with smart, intuitive software.'
                            },
                            {
                                q: 'How does Artifact improve efficiency?',
                                a: 'Artifact automates repetitive tasks, simplifies workflows, and provides real-time insights so teams can focus on strategic work instead of manual processes.'
                            },
                            {
                                q: 'What support options do you offer?',
                                a: 'We offer 24/7 customer support, a knowledge base, and dedicated account managers for enterprise customers.'
                            },
                            {
                                q: 'Is Artifact secure?',
                                a: 'Absolutely. We use enterprise-grade security, data encryption, and compliance standards to keep your information safe and operations running smoothly.'
                            },
                            {
                                q: 'Who is Artifact for?',
                                a: 'Artifact is designed for startups, growing businesses, and enterprises looking to streamline operations, reduce manual work, and make data-driven decisions.'
                            },
                            {
                                q: 'Is there a free trial available?',
                                a: "Yes! We offer a free trial so you can explore Artifact's features before committing. No credit card required to get started."
                            }
                        ];
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-2 md:gap-2 ",
                            children: faqs.map((f, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-white rounded-xl shadow-lg p-5 md:p-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-base md:text-lg font-semibold text-gray-900 mb-2",
                                            children: f.q
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                            lineNumber: 199,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm md:text-base text-gray-600 leading-relaxed",
                                            children: f.a
                                        }, void 0, false, {
                                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                            lineNumber: 200,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, i, true, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                    lineNumber: 198,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                            lineNumber: 196,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0));
                    })()
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                lineNumber: 164,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-16 md:mt-24 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 text-sm md:text-base",
                        children: "If you have any further questions or just want to reach our team, click the button below."
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 210,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "#contact",
                            className: "relative inline-flex items-center justify-center px-6 py-3 rounded-full bg-black text-white text-sm font-medium overflow-hidden group",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "block transition-all duration-500 group-hover:-translate-y-full group-hover:opacity-0",
                                    children: "Get in touch"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                    lineNumber: 219,
                                    columnNumber: 25
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$OneDrive$2f$Documents$2f$BY__ME__DEV$2f$Next$2f$Ass1$2f$xen$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute inset-0 flex items-center justify-center translate-y-full opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100",
                                    children: "Get in touch"
                                }, void 0, false, {
                                    fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                                    lineNumber: 224,
                                    columnNumber: 25
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                            lineNumber: 214,
                            columnNumber: 21
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                        lineNumber: 213,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
                lineNumber: 209,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/src/app/components/Customer.tsx",
        lineNumber: 31,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CustomerTestimonials, "/f4wnJmS4eCAxl+tCNvvn4G0rng=");
_c = CustomerTestimonials;
const __TURBOPACK__default__export__ = CustomerTestimonials;
var _c;
__turbopack_context__.k.register(_c, "CustomerTestimonials");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=OneDrive_Documents_BY%20ME%20DEV_Next_Ass1_xen_src_app_components_bcae0b50._.js.map