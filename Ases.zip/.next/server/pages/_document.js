var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/7684b_2e536ddf._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/document.js [ssr] (ecmascript)").exports
