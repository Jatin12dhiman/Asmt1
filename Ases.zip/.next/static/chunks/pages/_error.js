__turbopack_load_page_chunks__("/_error", [
  "static/chunks/7684b_next_dist_compiled_next-devtools_index_bd11238e.js",
  "static/chunks/7684b_next_dist_compiled_ecbeb8ae._.js",
  "static/chunks/7684b_next_dist_shared_lib_871420ee._.js",
  "static/chunks/7684b_next_dist_client_b1df54ef._.js",
  "static/chunks/7684b_next_dist_512fe459._.js",
  "static/chunks/7684b_next_error_a6b675cb.js",
  "static/chunks/[next]_entry_page-loader_ts_a9cb15f7._.js",
  "static/chunks/7684b_react-dom_cb8ca1db._.js",
  "static/chunks/7684b_96a8eb64._.js",
  "static/chunks/[root-of-the-server]__8e9b33bf._.js",
  "static/chunks/OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__error_2da965e7._.js",
  "static/chunks/turbopack-OneDrive_Documents_BY ME DEV_Next_Ass1_xen_pages__error_6159efb8._.js"
])
