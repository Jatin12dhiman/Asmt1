(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/error.js [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/OneDrive/Documents/BY ME DEV/Next/Ass1/xen/node_modules/next/dist/pages/_error.js [client] (ecmascript)");
}),
]);

//# sourceMappingURL=7684b_next_error_a6b675cb.js.map